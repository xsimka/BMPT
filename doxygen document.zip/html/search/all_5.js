var searchData=
[
  ['sken',['sken',['../main_final___e_n_8c.html#af34c7fcb3c066c5b599aac62347f02ec',1,'mainFinal_EN.c']]],
  ['sken_5fready',['sken_ready',['../main_final___e_n_8c.html#a24a37cc1986a949239d26c013312a19d',1,'mainFinal_EN.c']]]
];
