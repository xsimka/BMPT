

#define K 10
