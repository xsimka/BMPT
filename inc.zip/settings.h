/*
 * library with MCU settings
 *
 * autor: wykys
 * verze: 1.0
 * datum: 2.11.2017
 */

#ifndef F_CPU
#define F_CPU 16000000UL // Hz
#endif
